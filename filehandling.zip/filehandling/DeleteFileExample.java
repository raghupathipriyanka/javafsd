package filehandling;


import java.io.File;

public class DeleteFileExample {
    public static void main(String[] args) {
        File file = new File("example.txt");
        if (file.delete()) {
            System.out.println("Deletion successful.");
        } else {
            System.out.println("Deletion failed.");
        }
    }
}