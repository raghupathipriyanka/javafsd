package filehandling;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class UpdateFileExample {
    public static void main(String[] args) {
        File file = new File("example.txt");

        try {
            // create FileWriter object with boolean parameter set to true to enable append mode
            FileWriter writer = new FileWriter(file, true);

            // write content to the file
            writer.write("\nThis is new content added to the file.");

            // close the writer
            writer.close();

            System.out.println(" Done ");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}