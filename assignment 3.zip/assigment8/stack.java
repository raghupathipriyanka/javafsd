package assigment8;

import java.util.Stack;

public class stack {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(5);
        stack.push(10);
        stack.push(15);

        System.out.println("Stack elements after insertion:");
        System.out.println(stack);

        // Remove elements from the stack
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);

        System.out.println("Stack elements after removal:");
        System.out.println(stack);
    }
}

