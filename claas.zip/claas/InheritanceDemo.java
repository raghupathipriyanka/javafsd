package claas;
//Define a superclass called Animal
class Animal {
protected String species;

public Animal(String species) {
 this.species = species;
}

public void eat() {
 System.out.println("The " + species + " is eating.");
}

public void sleep() {
 System.out.println("The " + species + " is sleeping.");
}
}

//Define a subclass called Cat that extends Animal
class Cat extends Animal {
private String name;

public Cat(String name) {
 super("cat");
 this.name = name;
}

public void meow() {
 System.out.println("The cat named " + name + " is meowing.");
}
}

//Define another subclass called Dog that extends Animal
class Dog extends Animal {
private String name;

public Dog(String name) {
 super("dog");
 this.name = name;
}

public void bark() {
 System.out.println("The dog named " + name + " is barking.");
}
}

//Main program to demonstrate the use of inheritance
public class InheritanceDemo {
public static void main(String[] args) {
 // Create a Cat object and call its methods
 Cat cat = new Cat("Tom");
 cat.eat();
 cat.sleep();
 cat.meow();

 // Create a Dog object and call its methods
 Dog dog = new Dog("Rex");
 dog.eat();
 dog.sleep();
 dog.bark();
}
}


