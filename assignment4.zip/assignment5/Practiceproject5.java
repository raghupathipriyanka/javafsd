package assignment5;

public class Practiceproject5 {

	 public static void bubbleSort(int[] array) {
	        int n = array.length;

	        for (int i = 0; i < n - 1; i++) {
	            for (int j = 0; j < n - i - 1; j++) {
	                if (array[j] > array[j + 1]) {
	                    swap(array, j, j + 1);
	                }
	            }
	        }
	    }

	    public static void swap(int[] array, int i, int j) {
	        int temp = array[i];
	        array[i] = array[j];
	        array[j] = temp;
	    }

	    public static void main(String[] args) {
	        int[] array = {64, 34, 25, 12, 22, 11, 90};

	        System.out.println("Array before sorting:");
	        printArray(array);

	        bubbleSort(array);

	        System.out.println("Array after sorting:");
	        printArray(array);
	    }

	    public static void printArray(int[] array) {
	        for (int num : array) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }
	}
