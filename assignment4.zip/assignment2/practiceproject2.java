package assignment2;

public class practiceproject2 {
	    public static int binarySearch(int[] array, int target) {
	        int left = 0;
	        int right = array.length - 1;

	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (array[mid] == target) {
	                return mid;  // Return the index where the target is found
	            } else if (array[mid] < target) {
	                left = mid + 1;  // Continue searching in the right half
	            } else {
	                right = mid - 1;  // Continue searching in the left half
	            }
	        }

	        return -1;  // Return -1 if the target is not found
	    }

	    public static void main(String[] args) {
	        int[] array = {1, 2, 3, 5, 8, 10};
	        int target = 8;

	        int index = binarySearch(array, target);

	        if (index != -1) {
	            System.out.println("Target found at index " + index);
	        } else {
	            System.out.println("Target not found");
	        }
	    }
	}