package exceptionhandling;

class MyException extends Exception {
    private String message;

    public MyException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        try {
            System.out.println("Starting of try block");
            // I'm throwing the custom exception using throw
            throw new MyException("This is My error Message");
        } catch (MyException exp) {
            System.out.println("Catch Block");
            System.out.println(" MyException Occurred: " + exp.getMessage());
        }
    }
}