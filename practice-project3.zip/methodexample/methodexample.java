package methodexample;

public class methodexample {

    
   private int data = 150;
    
    public static void main(String[] args) {
        methodexample example = new methodexample();
        int multiplicationResult = example.multiply(5, 6);
        System.out.println("Multiplication is: " + multiplicationResult);
        System.out.println("Before operation value of data is: " + example.data);
        example.changeData();
        System.out.println("After operation value of data is: " + example.data);
        double triangleArea = calculateTriangleArea(6, 10);
        System.out.println("Area of triangle: " + triangleArea);
        double circleArea = calculateCircleArea(5);
        System.out.println("Area of circle: " + circleArea);
    }
    
    public int multiply(int num1, int num2) {
        return num1 * num2;
    }
    
    public void changeData() {
        data = data + 10;
    }
    
    public static double calculateTriangleArea(double base, double height) {
        return 0.5 * base * height;
    }
    
    public static double calculateCircleArea(double radius) {
        return Math.PI * radius * radius;
    }
}
