package AccessSpecifier;

public class AccessSpecifier{
	public static void main(String[] args) 
	{
	
	System.out.println("Dafault Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 
		priaccessspecifier obje = new priaccessspecifier(); 
		proaccessspecifiers obja = new proaccessspecifiers(); 
		pubaccessspecifiers objb = new pubaccessspecifiers(); 
		obj.display();
		obja.display2(); 
		objb.display3() ; 
		}
	} 
class defAccessSpecifier 
{
	void display() 
	{
		System.out.println("You are using defalut access specifier"); 
		} 
	} 
//2. using private access specifiers
class priaccessspecifier 
{ 
	private void display1()
	{ 
		System.out.println("You are using private access specifier"); 
		}
	}
//3. using protected access specifiers
class proaccessspecifiers {
	protected void display2() 
	{ 
		System.out.println("This is protected access specifier");
		}
	} 
//4. using public access specifiers 
class pubaccessspecifiers 
{ 
	public void display3()
{ 
	System.out.println("This is Public Access Specifiers");
	} 
	}
